/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package REPOSITORY;
import MODELS.doacao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author conta
 */
public class doacaoRepository {
    Connection conexao;
    
    //cadastrar doação de sangue
    public void createDoacao(doacao doacao1){
        
        try {
            String sql = "insert into doacao (banco,doador,tipo,quantidade) values (?,?,?,?)";
            
            conexao = new Conexao().conectaBD();
            
            PreparedStatement createSQL  = conexao.prepareStatement(sql);
            createSQL.setString(1,doacao1.getBanco());
            createSQL.setString(2,doacao1.getDoador());
            createSQL.setString(3,doacao1.getTipo());
            createSQL.setString(4,doacao1.getQuantidade());
            
            createSQL.execute();
            createSQL.close();
                    
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Não foi possivel cadastrar doação");
            Logger.getLogger(doacaoRepository.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    //visualizar doação de sangue
    public ArrayList<doacao> readAllDoacoesstatic() {
    
        return null;
    
}
    
    //atualizar doação de sangue
    public void updateDoacao(doacao doacao1){
        
    }
    
    //deletar doação de sangue
    public void deleteDoacao(doacao doacao1){
        
    }
}
