/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package SERVICES;

import MODELS.doacao;
import REPOSITORY.doacaoRepository;
import javax.swing.JOptionPane;

/**
 *
 * @author conta
 */
public class doacaoService {
    public static void cadastraDoacao(String banco, String doador, String tipo, String quantidade){
        
        doacao donate = new doacao(banco,doador,tipo,quantidade);
        
        doacaoRepository repository = new doacaoRepository();
        
        repository.createDoacao(donate);
        
        JOptionPane.showMessageDialog(null, "Doacao Cadastrada com Sucesso");
    }
}
